
import "../../assets/script/setRem.js"

import Vue from 'vue'

import FastClick from 'fastclick'
FastClick.attach(document.body)

import App from './App.vue'

Vue.config.productionTip = false

new Vue({
  render: h => h(App)
}).$mount('#app')