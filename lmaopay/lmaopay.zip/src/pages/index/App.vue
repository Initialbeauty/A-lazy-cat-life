<template>
<div class="main">
	
</div>
</template>

<script>
</script>

<style>
@import "../../assets/style/common.css";
.main{ height: 1rem; width: 3.75rem; background: #42B983;}
</style>
